// Seleção dos elementos do DOM
const rangeInput = document.getElementById('tech-range');
const techValSpan = document.getElementById('tech-val');
const barraProducao = document.getElementById('barra-producao');
const barraAmbiente = document.getElementById('barra-ambiente');
const diagnosticoTexto = document.getElementById('diagnostico');

// Função que atualiza o simulador
function atualizarSimulador() {
    const valor = parseInt(rangeInput.value);
    
    // Atualiza o texto do slider
    techValSpan.textContent = `${valor}%`;

    // Lógica de Equilíbrio:
    // Sem tecnologia (0%): Produção média/baixa devido ao esgotamento, Ambiente destruído.
    // Tecnologia Sustentável Máxima (100%): Produção altíssima e Ambiente totalmente preservado.
    let calculoProducao = 40 + (valor * 0.6); // Começa em 40% e vai até 100%
    let calculoAmbiente = valor; // Direto proporcional ao investimento sustentável

    // Atualiza o tamanho visual das barras
    barraProducao.style.width = `${calculoProducao}%`;
    barraAmbiente.style.width = `${calculoAmbiente}%`;

    // Atualiza o texto de diagnóstico baseado no equilíbrio
    if (valor < 30) {
        diagnosticoTexto.textContent = "⚠️ Alerta: Baixa sustentabilidade colocará em risco a produtividade no futuro devido à degradação do solo!";
        diagnosticoTexto.style.color = "#d32f2f";
    } else if (valor >= 30 && valor < 70) {
        diagnosticoTexto.textContent = "📈 Em evolução: Bom ritmo de produção, mas ainda há espaço para melhorar a preservação ambiental.";
        diagnosticoTexto.style.color = "#f57c00";
    } else {
        diagnosticoTexto.textContent = "🌾 AgroForte Perfeito! Alta produtividade garantida através de práticas 100% ecologicamente corretas.";
        diagnosticoTexto.style.color = "#2e7d32";
    }
}

// Ouvinte de evento para capturar as mudanças no slider
rangeInput.addEventListener('input', atualizarSimulador);

// Inicializa o simulador ao carregar a página
atualizarSimulador();